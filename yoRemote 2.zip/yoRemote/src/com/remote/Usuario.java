package com.remote;

public class Usuario 
{
	private long cedula;
	



	private String nombre;
	private String apellido;
	private String tipoTV;
	private String tipoInternet;
	private String tipoTelefonia;
	private boolean tieneHD;
	private String 	estadoCuenta;
	private String email;
	private String password;
	private long telefono;
	private String direccion;
	
	
	
	public void usuario()
	{
		
	}
	
	
	
	
	
	
	
	public long getCedula() {
		return cedula;
	}



	public void setCedula(long cedula) {
		this.cedula = cedula;
	}



	public String getNombre() {
		return nombre;
	}



	public void setNombre(String nombre) {
		this.nombre = nombre;
	}



	public String getApellido() {
		return apellido;
	}



	public void setApellido(String apellido) {
		this.apellido = apellido;
	}



	public String getTipoTV() {
		return tipoTV;
	}



	public void setTipoTV(String tipoTV) {
		this.tipoTV = tipoTV;
	}



	public String getTipoInternet() {
		return tipoInternet;
	}



	public void setTipoInternet(String tipoInternet) {
		this.tipoInternet = tipoInternet;
	}



	public String getTipoTelefonia() {
		return tipoTelefonia;
	}



	public void setTipoTelefonia(String tipoTelefonia) {
		this.tipoTelefonia = tipoTelefonia;
	}



	public boolean isTieneHD() {
		return tieneHD;
	}



	public void setTieneHD(boolean tieneHD) {
		this.tieneHD = tieneHD;
	}



	public String getEstadoCuenta() {
		return estadoCuenta;
	}



	public void setEstadoCuenta(String estadoCuenta) {
		this.estadoCuenta = estadoCuenta;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public long getTelefono() {
		return telefono;
	}



	public void setTelefono(long telefono) {
		this.telefono = telefono;
	}



	public String getDireccion() {
		return direccion;
	}



	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}







	public boolean loguearse(CharSequence text, CharSequence text2) {
		// TODO Auto-generated method stub
		return true;
	}
	
	
}
