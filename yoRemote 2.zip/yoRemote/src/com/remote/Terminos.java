package com.remote;

import android.app.Activity;
import android.os.Bundle;

public class Terminos extends Activity {
	
	public void onCreate(Bundle savedInstanceState) 
	{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.terminos);	
        
	}

}
